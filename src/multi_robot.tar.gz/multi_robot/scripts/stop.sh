#!/bin/sh
rosservice call /drone01/enable_motors false
rosservice call /drone02/enable_motors false
rosservice call /drone04/enable_motors false
rosservice call /drone05/enable_motors false
rosservice call /drone06/enable_motors false
rosservice call /drone07/enable_motors false
rosservice call /drone08/enable_motors false