#!/bin/sh
rosrun multi_robot test_d1.py
